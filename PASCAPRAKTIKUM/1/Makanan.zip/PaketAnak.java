public class PaketAnak extends Makanan {

    /**
     * Konstruktor
     */
    public PaketAnak() {
        super("Ayam Goreng", 150, "Susu");
    }
}