import java.util.Scanner;

public class Main {
    /**
     * Fungsi utama dari program kalkulator Hexaesar.
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int mode = scanner.nextInt();
        
        if (mode == 1 || mode == 2) {
            if (mode == 1) {
                System.out.println(Hexaesar.encrypt(scanner.next(), scanner.nextInt()));
            } else {
                System.out.println(Hexaesar.decrypt(scanner.next(), scanner.nextInt()));
            }
        } else {
            if (mode == 3) {
                System.out.println(Hexaesar.encrypt(scanner.nextInt(), scanner.nextInt()));
            } else {
                System.out.println(Hexaesar.decrypt(scanner.nextInt(), scanner.nextInt()));
            }
        }

        scanner.close();
    }
}