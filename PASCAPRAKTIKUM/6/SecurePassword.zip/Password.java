// Password.java
public class Password {
    private String password;

    public Password(String password) {
        this.password = password;
    }

    private boolean hasUpperCase() {
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                return true;
            }
        }
        return false;
    }

    private boolean hasNumber() {
        for (char c : password.toCharArray()) {
            if (Character.isDigit(c)) {
                return true;
            }
        }
        return false;
    }

    private boolean hasSpecialChar() {
        String specialChars = "!@#$%^&*(),./";
        for (char c : password.toCharArray()) {
            if (specialChars.indexOf(c) != -1) {
                return true;
            }
        }
        return false;
    }

    public boolean validate() throws InvalidLengthException, InvalidPasswordException {
        if (password.length() < 12) {
            throw new InvalidLengthException("Password harus memiliki panjang minimal 12 karakter");
        }
        if (!hasUpperCase()) {
            throw new InvalidPasswordException("Password harus mengandung minimal satu huruf kapital");
        }
        if (!hasNumber()) {
            throw new InvalidPasswordException("Password harus mengandung minimal satu angka");
        }
        if (!hasSpecialChar()) {
            throw new InvalidPasswordException("Password harus mengandung minimal satu karakter khusus");
        }
        return true;
    }
}

class InvalidPasswordException extends Exception {
    public InvalidPasswordException(String message) {
        super(message);
    }
}

class InvalidLengthException extends Exception {
    public InvalidLengthException(String message) {
        super(message);
    }
}
