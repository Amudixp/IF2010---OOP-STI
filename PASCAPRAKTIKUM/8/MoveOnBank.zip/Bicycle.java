public interface Bicycle {
    public void changeCadence (int newValue); //Nama dari method, lengkap dengan 
}
