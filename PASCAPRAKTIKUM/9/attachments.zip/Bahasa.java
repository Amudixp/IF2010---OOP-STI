import java.util.ArrayList;

public abstract class Bahasa {
    protected ArrayList<String> files;
    protected String extention;

    public Bahasa(ArrayList<String> files) {
        this.files = files;
    }
    
    // Menghapus extention dari akhir nama file
    // Contohnya: namaFile "Main.jawa" akan berubah menjadi "Main"
    public String removeExtention(String namaFile) {
        return namaFile.split("\\.")[0];
    }

    public abstract void compile() throws BahasaError;
    public abstract void grade(String inputFilename, String outputFilename) throws BahasaError;

}

class BahasaFactory {
    
    // Mengembalikan kelas bahasa untuk namaBahasa yang diberikan. Jika bahasa adalah selain: 
    // - "Jawa"
    // - "C"
    // - "Ular"
    // Maka ia akan mengembalikan error
    public static Bahasa getBahasaRunner(String namaBahasa, ArrayList<String> files) throws BahasaError {
        if ("Jawa".equals(namaBahasa)) {
            return new BahasaJawa(files);
        }
        if ("C".equals(namaBahasa)) {
            return new BahasaC(files);
        }
        if ("Ular".equals(namaBahasa)) {
            return new BahasaUlar(files);
        }
        throw new BahasaNotExistsException();
    }
}

class BahasaError extends Exception {
    public BahasaError() {
        super();
    }

    public BahasaError(String message) {
        super(message);
    }
}

class WrongExtentionException extends BahasaError {
    public WrongExtentionException(String supposedExtention, String filename) {
        super("Expected extention \"" + supposedExtention + "\" for " + filename);
    }
}

class TestcaseMismatchException extends BahasaError {
    public TestcaseMismatchException(String inputFilename, String outputFilename) {
        super("Input testcase for " + inputFilename + " got output filename of " + outputFilename);
    }
}

class BahasaNotExistsException extends BahasaError {
    public BahasaNotExistsException() {
        super("Bahasa doesn't exists!");
        // Mengembalikan pesan error "Bahasa doesn't exists!"
    }
}