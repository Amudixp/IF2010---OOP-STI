import java.util.ArrayList;

public class BahasaUlar extends Bahasa {
    public BahasaUlar(ArrayList<String> files) {
        super(files);
        extention = ".piton";
    }

    public void compile() throws BahasaError {

        /* Tambahkan error checking disini */
        for (String file : files) {
            if (!file.endsWith(extention)) {
                throw new WrongExtentionException(extention, file);
            }
        }
        System.out.println();
    }

    public void grade(String inputFilename, String outputFilename) throws BahasaError {
        /* Tambahkan error checking disini */
        if (!inputFilename.endsWith(".in")) {
            throw new WrongExtentionException(".in", inputFilename);
        }
        if (!outputFilename.endsWith(".out")) {
            throw new WrongExtentionException(".out", outputFilename);
        }
        if (!removeExtention(inputFilename).equals(removeExtention(outputFilename))) {
            throw new TestcaseMismatchException(inputFilename, outputFilename);
        }
        System.out.println("piton " + removeExtention(files.get(0)) + " < " + inputFilename + " > " + outputFilename);
    }
}
