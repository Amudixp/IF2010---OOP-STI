import java.util.ArrayList;
import java.util.Scanner;

public class BukanOlympia {
  public static void main(String[] args) {
    Scanner s = new Scanner(System.in);
    String namaBahasa = s.nextLine();
    int jumlahFile = Integer.parseInt(s.nextLine());
    ArrayList<String> files = new ArrayList<>();
    for (int i = 0; i < jumlahFile; i++) {
      files.add(s.nextLine());
    }

    Bahasa bahasa;
    try {
      bahasa = BahasaFactory.getBahasaRunner(namaBahasa, files);
    } catch (BahasaNotExistsException e) {
      System.out.println(e.getMessage());
      s.close();
      return; // Keluar dari program
    }
    // Menangkap BahasaError lain dari factory jika ada (seharusnya tidak terjadi
    // dengan implementasi saat ini)
    catch (BahasaError e) {
      System.out.println(e.getMessage());
      s.close();
      return;
    }

    try {
      bahasa.compile();
    } catch (BahasaError e) { // Ini akan menangkap WrongExtentionException dari compile
      System.out.println(e.getMessage());
      s.close();
      return; // Keluar dari program
    }

    int jumlahTestCase = Integer.parseInt(s.nextLine());
    for (int i = 0; i < jumlahTestCase; i++) {
      String testcaseLine = s.nextLine();
      String[] inputOutputPair = testcaseLine.split(" ");

      // Pastikan format baris testcase benar sebelum mengakses elemen array
      if (inputOutputPair.length < 2) {
        // Sesuai aturan, jika error pada grade, cetak pesan dan lanjut.
        // Ini adalah error format input, bukan dari grade(), tapi kita tangani agar
        // tidak crash.
        System.out.println("Invalid testcase line format: " + testcaseLine);
        continue; // Lanjut ke testcase selanjutnya
      }
      String inputFilename = inputOutputPair[0];
      String outputFilename = inputOutputPair[1];

      try {
        bahasa.grade(inputFilename, outputFilename);
      } catch (BahasaError e) { // Ini akan menangkap WrongExtentionException atau TestcaseMismatchException
                                // dari grade
        System.out.println(e.getMessage());
        // Lanjut ke testcase selanjutnya (loop akan berlanjut)
      }
    }
    s.close(); // Tutup scanner di akhir
  }
}