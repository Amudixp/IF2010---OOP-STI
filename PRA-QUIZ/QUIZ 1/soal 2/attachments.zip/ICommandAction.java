/**
 * ICommandAction.java
 * [Jelaskan kegunaan interface ini]
 * 
 * @author [NIM] [Nama]
 */

public interface ICommandAction {
    void execute();
    void undo();
}