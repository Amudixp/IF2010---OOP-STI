public interface IHandler {    
    public void writeRequest(RequestData data);
    
    public void readRequest(RequestData data);
}
