public class JSONHandler implements IHandler {
    public void writeRequest(RequestData data) {
        // IMPLEMENTASI DISINI
    }

    public void readRequest(RequestData data) {
        // IMPLEMENTASI DISINI
    }
}
