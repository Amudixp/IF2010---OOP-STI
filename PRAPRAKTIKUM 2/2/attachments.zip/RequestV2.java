public class RequestV2 extends Request {
    /*
     * Konstruktor RequestV2 yang menerima parameter requestData
     * Sesuaikan dengan kebutuhan
     */
    public RequestV2(RequestData requestData) {
        // IMPLEMENTASI DISINI
    }

    /*
     * Mengoverride method sendRequest yang ada di class Request dengan menggunakan JSONHandler
     * Lakukan hal yang sama dengan pola pada method sendRequest di class Request
     */
    public void sendRequest(String url) {
        // IMPLEMENTASI DISINI
    }

    /*
     * Mengoverride method readRequest yang ada di class Request dengan menggunakan JSONHandler
     * Lakukan hal yang sama dengan pola pada method readRequest di class Request
     */
    public void readRequest(String url) {
        // IMPLEMENTASI DISINI
    }
}
