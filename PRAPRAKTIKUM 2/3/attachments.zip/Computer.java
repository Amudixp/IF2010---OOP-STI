public interface Computer {
    public void compute(int x, int y);

    public void printSpecification();
}