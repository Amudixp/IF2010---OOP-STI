public interface Keyboard {
    public void useKeyboard();

    public void printIsRGB();
}
