public interface Monitor {
    public void turnOnMonitor();

    public void turnOffMonitor();

    public void printResolution();
}
