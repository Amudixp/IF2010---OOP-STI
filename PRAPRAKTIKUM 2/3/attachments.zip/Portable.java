public interface Portable {
    public void move();

}
